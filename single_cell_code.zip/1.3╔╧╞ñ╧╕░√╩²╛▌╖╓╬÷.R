library(harmony)
library(DoubletFinder)
library(tidyverse)
library(Seurat)
library(patchwork)
sq_epi<-readRDS("D:\\ESCC\\196756+188900\\0DATA\\epi.rds")


seurat_obj_epi<-sq_epi@assays$RNA@counts


seurat_obj_epi<-as.matrix(seurat_obj_epi)
seurat_obj_epi <- CreateSeuratObject(counts = seurat_obj_epi,
                                          min.features = 200,
                                          min.cells = 5, 
                                          project = "epi")





head(seurat_obj_epi@meta.data,5)
seurat_obj_epi[["percent.mt"]] <- PercentageFeatureSet(seurat_obj_epi, pattern = "^MT-")
seurat_obj_epi <- SCTransform(seurat_obj_epi, verbose = T, vars.to.regress = c("nCount_RNA", "percent.mt"), conserve.memory = T)


seurat_obj_epi  <- RunPCA(seurat_obj_epi , verbose = F)

ElbowPlot(seurat_obj_epi , ndims = 50)


gc()
library(harmony)
####开始harmony合并
seurat_obj_epi  <-seurat_obj_epi %>% RunHarmony("orig.ident", plot_convergence = T)
#最终使用的维数
pct<-seurat_obj_epi  [["harmony"]]@stdev/sum(seurat_obj_epi  [["harmony"]]@stdev)*100
cumu<-cumsum(pct)
co1<-which(cumu >80 & pct<5)[1]
co2 <- sort(which((pct[1:length(pct) - 1] - pct[2:length(pct)]) > 0.1), decreasing = T)[1] + 1
co2 <- min(co1,co2)
co2#这里是数据选择的最优主成分
pc.num=1:co2
#降维聚类
seurat_obj_epi  <- RunUMAP(seurat_obj_epi ,reduction="harmony", dims=pc.num,seed.use=123456L)
seurat_obj_epi  <- RunTSNE(seurat_obj_epi ,reduction="harmony", dims=pc.num,seed.use = 123456)
seurat_obj_epi <- FindNeighbors(seurat_obj_epi ,reduction="harmony",dims = pc.num,k.param = 20)
DimPlot(seurat_obj_epi ,reduction = "tsne")

seurat_obj_epi  <- FindClusters(seurat_obj_epi ,random.seed=123456,resolution=c(0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,1,1.2))
cpoykat<-read.table("D:\\ESCC\\196756+188900\\OS_copykat_prediction.txt",header = T)
colnames(cpoykat)[1]<-c("cell")
metdata<-seurat_obj_epi@meta.data
metadata_merge<-metdata
metadata_merge$cell<-rownames(metadata_merge)

metadata_merge<-merge(metadata_merge,cpoykat,by="cell")

rownames(metadata_merge)<-metadata_merge[,1]
metadata_merge<-metadata_merge[,-1]


sq_epi<-AddMetaData(sq_epi,metadata_merge)


Idents(sq_epi)<-sq_epi$copykat.pred
DimPlot(sq_epi)
table(sq_epi$sample)
sq_epi<-subset(sq_epi,subset=sample=="Tumor")
table(sq_epi$copykat.pred)
# 创建一个包含类别和对应数量的向量
copykat_pred_counts <- c(aneuploid = 6763, diploid = 6059, `not.defined` = 1276)

# 绘制柱状图
barplot(copykat_pred_counts,
        main = "CopyKAT Prediction Counts", # 图表标题
        xlab = "Prediction Type",            # X轴标签
        ylab = "Frequency",                  # Y轴标签
        col = c("skyblue", "lightgreen", "khaki"), # 柱子颜色
        las = 1,                             # 使Y轴数字水平显示
        ylim = c(0, max(copykat_pred_counts) + 500)) # 设置y轴范围以适应最大值

# 添加数值到柱状图上（可选）
text(x = barplot(copykat_pred_counts, plot = FALSE),
     y = copykat_pred_counts,
     label = copykat_pred_counts,
     pos = 3,                                # 文字位置调整
     offset = 0.5,                           # 偏移量
     cex = 0.8)                              # 字体大小调整

DimPlot(sq_epi)
moncle<-subset(sq_epi,subset=c(copykat.pred=="diploid"|copykat.pred=="aneuploid"))
DotPlot(moncle,features = c("RUNX1","TP63","GLI2"))



expr <- moncle@assays$RNA
gene_expression <- expr %>% .['RUNX1',] %>% as.data.frame() %>% t()
gene_expression <- as.data.frame(gene_expression)
metadata_moncle<-moncle@meta.data
metadata_moncle$cell<-rownames(metadata_moncle)
metadata_moncle<-metadata_moncle[,c(23,24)]
colnames(gene_expression) <- 'RUNX1'

gene_expression$cell <- rownames(gene_expression)
gene_expression<-merge(gene_expression,metadata_moncle,by="cell")
table(gene_expression$copykat.pred)

gene_expression_an<-subset(gene_expression,subset=copykat.pred=="aneuploid")
gene_expression_di<-subset(gene_expression,subset=copykat.pred=="diploid")

gene_expression_sel <- gene_expression_an[which(gene_expression_an$RUNX1 > 0),]
gene_expression_sel <- gene_expression_di[which(gene_expression_di$RUNX1 > 0),]

dim(gene_expression_sel) / dim(gene_expression)




VlnPlot(moncle,features =c("RUNX1","TP63"),pt.size =0  )+stat_compare_means(comparisons = comparisons)



a<-VlnPlot(moncle,features = c("RUNX1"),pt.size = 0)+
  NoLegend() +
  theme(axis.text.x = element_text(angle = 90, hjust = 1)) +
  stat_compare_means(comparisons = comparisons, label = "p.format",method =  "wilcox.test") +
  ylim(0,2.5)
a

gc()
epi_counts<-as.data.frame(t(as.matrix(moncle@assays$SCT@data)))
epi_meatdata<-moncle@meta.data

GLI2<-as.data.frame(epi_counts$GLI2)
GLI2$cell<-rownames(epi_counts)
colnames(GLI2)[1]<-"GLI2_expression"
epi_meatdata$cell<-rownames(epi_meatdata)
metadata<-merge(GLI2,epi_meatdata,by="cell")
comparisons<-list(c("aneuploid","diploid"))


library(ggpubr)
#####小提琴图
p<-ggplot(metadata, aes(x = reorder(copykat.pred,GLI2_expression),GLI2_expression)) # x分组变量，y表达变量

b<-p+geom_violin(aes(fill = copykat.pred))+#geom_boxplot(width = 0.2)+
  guides(fill = "none") + xlab(NULL) + theme_classic()+ggtitle("epi_GLI2") +NoLegend() +
  theme(axis.text.x = element_text(angle = 90, hjust = 1)) +
  stat_compare_means(comparisons = comparisons, label = "p.format",method =  "wilcox.test") +
  ylim(0,1.2)


b








library(monocle)
library(dplyr)
library(Seurat)
library(patchwork)
library(tidyr)


##提取表型信息--细胞信息(建议载入细胞的聚类或者细胞类型鉴定信息、实验条件等信息)
celltype<-moncle$copykat.pred
celltype<-as.data.frame(celltype)
celltype$cellname<-rownames(celltype)

celltype$sample<-substr(celltype$cellname,1,10)
celltype2<-unite(celltype,"cellnamenew",c("celltype","sample"), sep="-", remove = F)
moncel2<-moncle
moncel2$cellname<-celltype2$cellnamenew


expr_matrix <- as(as.matrix(moncel2@assays$RNA@counts), 'sparseMatrix')
##提取表型信息到p_data(phenotype_data)里面 

p_data <- moncel2@meta.data
#p_data$celltype <- pbmc@active.ident  ##整合每个细胞的细胞鉴定信息到p_data里面。如果已经添加则不必重复添加
f_data <- data.frame(gene_short_name = row.names(moncel2),row.names = row.names(moncel2))
##expr_matrix的行数与f_data的行数相同(gene number), expr_matrix的列数与p_data的行数相同(cell number)
#构建CDS对象(一定要确保identical(rownames(fd),rownames(expr_matrix))为TURE
gc()

pd <- new('AnnotatedDataFrame', data = p_data) 
fd <- new('AnnotatedDataFrame', data = f_data)
rownames(fd)
rownames(expr_matrix)
expr_matrix<- expr_matrix[rownames(fd), ]



identical(rownames(fd),rownames(expr_matrix))

remove(moncle)

#将p_data和f_data从data.frame转换AnnotatedDataFrame对象。
cds <- newCellDataSet(expr_matrix,
                      phenoData = pd,
                      featureData = fd,
                      lowerDetectionLimit = 0.5,
                      expressionFamily = negbinomial.size())

remove(expr_matrix)
library(data.table)
gc()
cds <- estimateSizeFactors(cds)
cds <- estimateDispersions(cds)
cds <- detectGenes(cds, min_expr = 0.1)
gc()
dim(cds)
print(head(fData(cds)))#此时有13714个基因
expressed_genes <- row.names(subset(fData(cds),
                                    num_cells_expressed >= 10)) #过滤掉在小于10个细胞中表达的基因，还剩11095个基因。
#这一步输入的expressed_genes来自于步骤4。
#️️后续分析使用的是该方法
#也可输入seurat筛选出的高变基因：expressed_genes <- VariableFeatures(pbmc) 
####diff这一流程里面的fullModelFormulaStr后输入的应该是你自己的细胞分类或者注释结果

###########选择轨迹基因
##使用seurat选择的高变基因⚠️
escc_sq<-FindVariableFeatures(escc_sq)
express_genes <- VariableFeatures(escc_sq)
cds <- setOrderingFilter(cds, express_genes)
plot_ordering_genes(cds)

###########选择轨迹基因
##使用seurat选择的高变基因⚠️
escc_sq<-FindVariableFeatures(escc_sq)
express_genes <- VariableFeatures(escc_sq)
cds <- setOrderingFilter(cds, express_genes)
plot_ordering_genes(cds)

##使用monocle选择的高变基因⚠️
disp_table <- dispersionTable(cds)
disp.genes <- subset(disp_table, mean_expression >= 0.1 & dispersion_empirical >= 1 * dispersion_fit)$gene_id
cds <- setOrderingFilter(cds, disp.genes)
plot_ordering_genes(cds)


##使用clusters差异表达基因
Idents(moncel2)<-moncel2$copykat.pred
table(moncel2$copykat.pred)
DefaultAssay(moncel2)
deg.cluster <- FindAllMarkers(moncel2,min.pct = 0.1,logfc.threshold = 0.25)
express_genes <- subset(deg.cluster,p_val<0.05)$gene
cds <- setOrderingFilter(cds, express_genes)
plot_ordering_genes(cds)


diff <- differentialGeneTest(cds[express_genes,],fullModelFormulaStr="~copykat.pred",cores=1) 
#~后面是表示对谁做差异分析的变量，理论上可以为p_data的任意列名
head(diff)

##差异表达基因作为轨迹构建的基因,差异基因的选择标准是qval<0.01,decreasing=F表示按数值增加排序
deg <- subset(diff, qval < 0.01) #选出2829个基因
deg <- deg[order(deg$qval,decreasing=F),]
head(deg)

##差异基因的结果文件保存
write.table(deg,file="train.monocle.DEG.xlsx",col.names=T,row.names=F,sep="\t",quote=F)
DimPlot(moncel, reduction = "umap",group.by = "integrated_snn_res.0.1")
## 轨迹构建基因可视化
ordergene <- rownames(deg) 
cds <- setOrderingFilter(cds, ordergene)  
#这一步是很重要的，在我们得到想要的基因列表后，我们需要使用setOrderingFilter将它嵌入cds对象，后续的一系列操作都要依赖于这个list。
#setOrderingFilter之后，这些基因被储存在cds@featureData@data[["use_for_ordering"]]，可以通过table(cds@featureData@data[["use_for_ordering"]])查看
pdf("train.ordergenes.pdf")
plot_ordering_genes(cds)
dev.off()
#出的图黑色的点表示用来构建轨迹的差异基因，灰色表示背景基因。红色的线是根据第2步计算的基因表达大小和离散度分布的趋势(可以看到，找到的基因属于离散度比较高的基因
cds <- reduceDimension(cds, max_components = 2,
                       method = 'DDRTree')

gc()
cds <- orderCells(cds)
#️使用root_state参数可以设置拟时间轴的根，如下面的拟时间着色图中可以看出，左边是根。根据state图可以看出，根是State1，若要想把另一端设为根，可以按如下操作
cds <- orderCells(cds, root_state = 3) #把State5设成拟时间轴的起始点

plot_cell_trajectory(cds,color_by="Pseudotime", size=1,show_backbone=TRUE) 

plot_cell_trajectory(cds,color_by="main_cell_type", size=1,show_backbone=TRUE)

plot_cell_trajectory(cds, color_by = "copykat.pred",size=1,show_backbone=TRUE)
cds$orig.ident
cds$SCT_snn_res.0.1
plot_cell_trajectory(cds, color_by = "SCT_snn_res.0.1",size=1,show_backbone=TRUE)
plot_cell_trajectory(cds, color_by = "State",size=1,show_backbone=TRUE)


exprData <- cds@assayData$exprs
exprData <- LogNormalize(exprData) #对数据normaliza一下，会比较显著，记得引用seurat包
cds$TP63<- exprData["TP63",] #输入想看的基因，cds是monocle的对象
plot_cell_trajectory(cds, color_by = "TP63",cell_size=1,show_backbone=TRUE)+scale_colour_gradient(low="grey",high = "red")












