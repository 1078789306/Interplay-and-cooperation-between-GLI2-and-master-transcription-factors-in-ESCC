library(harmony)
library(DoubletFinder)
library(tidyverse)
library(Seurat)
library(patchwork)
library(readxl)
#remotes::install_github('lzmcboy/DoubletFinder_204_fix')
gc()


seu_obj_f <- RunPCA(seu_obj_f, verbose = F)

ElbowPlot(seu_obj_f, ndims = 50)


gc()
library(harmony)
####开始harmony合并
seu_obj_f <-seu_obj_f%>% RunHarmony("orig.ident", plot_convergence = T)
#最终使用的维数
pct<-seu_obj_f [["harmony"]]@stdev/sum(seu_obj_f [["harmony"]]@stdev)*100
cumu<-cumsum(pct)
co1<-which(cumu >80 & pct<5)[1]
co2 <- sort(which((pct[1:length(pct) - 1] - pct[2:length(pct)]) > 0.1), decreasing = T)[1] + 1
co2 <- min(co1,co2)
co2#这里是数据选择的最优主成分
pc.num=1:co2
#降维聚类
seu_obj_f <- RunUMAP(seu_obj_f,reduction="harmony", dims=pc.num,seed.use=123456L)
seu_obj_f <- RunTSNE(seu_obj_f,reduction="harmony", dims=pc.num,seed.use = 123456)
seu_obj_f<- FindNeighbors(seu_obj_f,reduction="harmony",dims = pc.num,k.param = 20)
DimPlot(seu_obj_f,reduction = "tsne")

seu_obj_f <- FindClusters(seu_obj_f,random.seed=123456,resolution=c(0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,1,1.2))
seu_obj_f$SCT_snn_res.0.1
p1 <- clustree(seu_obj_f, prefix = 'SCT_snn_res.')
p1

Idents(seu_obj_f)<-seu_obj_f$orig.ident

Idents(seu_obj_f)<-seu_obj_f$SCT_snn_res.0.1
DimPlot(seu_obj_f,reduction = "umap")

DefaultAssay(seu_obj_f)<-"SCT"


celltype_marker<-c("MS4A1","CD79A","CD79B","IGHG1","IGHM","KRT5","KRT7","EPCAM","CD3D","CD3E","CD3G","CD68","CD163","C1QA","C1QB","C1QC","PECAM1","VWF","CPA3","TPSAB1","TPSB2","COL1A1","COL1A2","COL1A3","FABP4","CD14","CLEC12A","RGS5","MYH11","TAGLN")



DotPlot(seu_obj_f, features = celltype_marker)+RotatedAxis()+
  scale_x_discrete("")+scale_y_discrete("")



seu_obj_f.markers <- FindAllMarkers(object =seu_obj_f, only.pos = TRUE, 
                               min.pct = 0, 
                               thresh.use = 0.25)






markers_df = seu_obj_f.markers_f %>% group_by(cluster) %>% top_n(n = 20, wt = avg_log2FC)


DefaultAssay(seu_obj_f)<-"SCT"
DoHeatmap(seu_obj_f,features = markers_df$gene,label = F,slot = "scale.data")
library(readxl)
annotation_curated_main <- read_excel("D:\\ESCC\\196756+188900\\0DATA\\curated_annotation_mainV2.xlsx")
gc()

new_ids_main <- annotation_curated_main$main_cell_type
names(new_ids_main) <- levels(seu_obj_f)
seu_obj_f <- RenameIdents(seu_obj_f, new_ids_main)
seu_obj_f@meta.data$main_cell_type <- Idents(seu_obj_f)
DimPlot(seu_obj_f, reduction = "umap", label = TRUE, pt.size = 0.5) 

table(seu_obj_f$orig.ident)

seu_obj_f@meta.data$sample[seu_obj_f$orig.ident=="GSM5691642"|seu_obj_f$orig.ident=="GSM5691643"|seu_obj_f$orig.ident=="GSM5691644"|seu_obj_f$orig.ident=="GSM5691645"|seu_obj_f$orig.ident=="GSM5691646"|seu_obj_f$orig.ident=="GSM5691647"|seu_obj_f$orig.ident=="GSM5691648"|seu_obj_f$orig.ident=="GSM5900215"|seu_obj_f$orig.ident=="GSM5900217"|seu_obj_f$orig.ident=="GSM5900219"]<-"Tumor"
seu_obj_f@meta.data$sample[seu_obj_f$orig.ident=="GSM5691649"|seu_obj_f$orig.ident=="GSM5900216"|seu_obj_f$orig.ident=="GSM5900218"|seu_obj_f$orig.ident=="GSM5900220"]<-"Normal"
TF_26<-read.table("D:\\ESCC_LIU\\List1-26-TFs.txt")
markers<-TF_26$V1
Idents(seu_obj_f)<-seu_obj_f$sample


DefaultAssay(seu_obj_f)<-"SCT"



table(GSE188900$main_cell_type)

#计算平均表达量
gene_cell_exp <- AverageExpression(seu_obj_f,
                                   features = TF_26$V1,
                                   group.by = 'sample',
                                   slot = 'data') 
gene_cell_exp <- as.data.frame(gene_cell_exp$RNA)

#complexheatmap作图
library(ComplexHeatmap)
#顶部细胞类型注释
df <- data.frame(colnames(gene_cell_exp))
colnames(df) <- 'class'
top_anno = HeatmapAnnotation(df = df,#细胞名/cluster
                             border = T,
                             show_annotation_name = F,
                             gp = gpar(col = 'black'),
                             col = list(class = c('Tumor'="#9ECABE",
                                                  'Normal'="#F6F5B4")))#颜色设置
#数据标准化缩放一下
marker_exp <- t(scale(t(gene_cell_exp),scale = T,center = T))
Heatmap(marker_exp,
        cluster_rows = T,
        cluster_columns = F,
        show_column_names = F,
        show_row_names = T,
        column_title = NULL,
        heatmap_legend_param = list(
          title=' '),
        col = colorRampPalette(c("#98F5FF","white","#FF4040"))(5),
        border = 'black',
        rect_gp = gpar(col = "black", lwd = 1),
        row_names_gp = gpar(fontsize = 10),
        column_names_gp = gpar(fontsize = 10),
        top_annotation = top_anno)

saveRDS(seu_obj_f,"D:\\ESCC\\196756+188900\\0DATA\\ESCC_注释.rds")
####全部的correlation
table(seu_obj_f$main_cell_type)
sq_epi<-subset(seu_obj_f,subset = main_cell_type=="Epithelial cells")
sq_epi2<-subset(sq_epi,subset=sample=="Tumor")

sq_epi_data<-as.data.frame(sq_epi2@assays$RNA@data)

save(sq_epi_data,
     file = "D:\\ESCC_LIU\\escc.RData")


sq_epi_data$gene<-rownames(sq_epi_data)
TF_6<-read.table("D:\\ESCC_LIU\\List1-26-TFs.txt")

TF_6<-as.data.frame(c("MAFK","ETV4","BHLHE40","KLF13","RXRA","RUNX1","TP63","GLI2","SMAD3","SREBF1","ZNF217","TGIF1","TP73","TFAP2A"))



colnames(TF_6)<-"gene"
sq_epi_data2<-merge(sq_epi_data,TF_6,by="gene")
rownames(sq_epi_data2)<-sq_epi_data2[,1]
sq_epi_data2<-sq_epi_data2[,-1]

corr<-round(cor(t(sq_epi_data2)),3)
library(ggcorrplot)
library(corrplot)
p.mat<-round(cor_pmat(t(sq_epi_data2)),3)
col2 <- colorRampPalette( c("#053061","#2166AC","#4393C3", "#92C5DE", "#D1E5F0", "#FFFFFF","#FDDBC7", "#F4A582", "#D6604D", "#B2182B","#67001F"))(100)
# 绘制相关性热图




corr<-corr[c(5,13,17,22,1:4,6:12,14:16,18:21,23:26),]

corr<-corr[,c(5,13,17,22,1:4,6:12,14:16,18:21,23:26)]


corr<-corr[c(3,6,12,1:2,4:5,7:11,13:14),]

corr<-corr[,c(3,6,12,1:2,4:5,7:11,13:14)]

corrplot(corr, method = "square", col = col2)

table(sq_epi$copykat.pred)
remove(sq_epi)
gc()

saveRDS(sq_epi,"D:\\ESCC\\196756+188900\\0DATA\\epi.rds")



