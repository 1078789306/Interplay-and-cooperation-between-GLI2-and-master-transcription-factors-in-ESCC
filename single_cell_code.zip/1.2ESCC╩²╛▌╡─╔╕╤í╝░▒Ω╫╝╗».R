library(Seurat)
library(dplyr)
library(reticulate)
library(sctransform)
library(cowplot)
library(ggplot2)
library(viridis)
library(tidyr)
library(magrittr)
library(reshape2)
library(readxl)
library(progeny)
library(readr)
library(stringr)
library(clustree)
library(patchwork)
######筛选条件的选择
nFeature_lower <- 500
nFeature_upper <- 10000
nCount_lower <- 1000
nCount_upper <- 100000
pMT_lower <- 0
pMT_upper <- 20
pHB_lower <- 0
pHB_upper <- 5
gc()
seu_obj<-readRDS("D:\\ESCC\\196756+188900\\0DATA\\ESCC_merge.rds")
# The [[ operator can add columns to object metadata. This is a great place to stash QC stats
seu_obj[["percent.mt"]] <- PercentageFeatureSet(seu_obj, pattern = "^MT-")

# 查看QC指标
# Show QC metrics for the first 5 cells
head(seu_obj@meta.data, 5)
######可视化QC的指标
qcparams <- c("nFeature_RNA", "nCount_RNA", "percent.mt" )
for (i in seq_along(qcparams)){
  print(VlnPlot(object = seu_obj, features = qcparams[i], group.by = "orig.ident", pt.size = 0))
}
for (i in seq_along(qcparams)){
  print(RidgePlot(object = seu_obj, features = qcparams[i], group.by = "orig.ident"))
}

VlnPlot(seu_obj, features = c("nFeature_RNA", "nCount_RNA", "percent.mt"), group.by = "orig.ident", ncol = 3, log = T,pt.size = 0,raster=FALSE)


######每个指标之间的相关性（相关性图的作用：让我们更好的认识到筛选条件，首先具有生物学意义的细胞，那其nFeature_RNA与nCount_RNA应该呈现近似的正相关，且越靠近左下，我们会认为细胞的质量越差（一般认为有生物学意义的细胞其基因数量与mRNA数量应该都高），但是其基因数量与mRNA数量又不能都太高，这样可能是因为一个液滴中包含了多个细胞的缘故。而mt与nCount_RNA之间的关系图则主要是表示若mRNA数量极少而线粒体几多可能是受损或者垂死的细胞其细胞质mRNA通过破损的核膜泄露）
######ncount_RNA代表了转录成mRNA的多少，那它是不是筛选的金标准呢？如果一个样本其ncount_RNA很低代表了什么呢
plot1 <- FeatureScatter(seu_obj, feature1 = "nCount_RNA", feature2 = "percent.mt",raster=FALSE)
plot2 <- FeatureScatter(seu_obj, feature1 = "nCount_RNA", feature2 = "nFeature_RNA",raster=FALSE)
plot1 + plot2
gc()




seu_obj_f <- subset(seu_obj, subset = nFeature_RNA > nFeature_lower & nFeature_RNA < nFeature_upper & nCount_RNA > nCount_lower & nCount_RNA < nCount_upper & percent.mt < pMT_upper )
table(seu_obj_f$orig.ident)
saveRDS(seu_obj_f,"D:\\ESCC\\196756+188900\\0DATA\\ESCC_filter.rds")
seu_obj_f<-readRDS("D:\\ESCC\\196756+188900\\0DATA\\ESCC_filter.rds")
gc()
reticulate::py_install(packages ='umap-learn')

seu_obj_f <- PercentageFeatureSet(seu_obj_f, pattern = "^MT-", col.name = "pMT")##线粒体计数
seu_obj_f <- PercentageFeatureSet(seu_obj_f, pattern = "^HBA|^HBB", col.name = "pHB")##血红蛋白计数
seu_obj_f <- PercentageFeatureSet(seu_obj_f, pattern = "^RPS|^RPL", col.name = "pRP")##核糖体计数
remove(seu_obj)
gc()
seu_obj_f <- SCTransform(seu_obj_f, verbose = T, vars.to.regress = c("nCount_RNA", "pMT"), conserve.memory = T)
