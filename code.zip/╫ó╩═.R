library(Seurat)
library(dplyr)
library(reticulate)
library(sctransform)
library(cowplot)
library(ggplot2)
library(viridis)
library(tidyr)
library(magrittr)
library(reshape2)
library(readxl)
library(progeny)
library(readr)
library(stringr)
library(clustree)
library(patchwork)
######筛选条件的选择
nFeature_lower <- 500
nFeature_upper <- 10000
nCount_lower <- 1000
nCount_upper <- 100000
pMT_lower <- 0
pMT_upper <- 10
pHB_lower <- 0
pHB_upper <- 5
total_ESCC_all<-total_MHeR
remove(total_MHeR)

total_ESCC_all$main_cell_type
DimPlot(total_ESCC_all,reduction = "tsne",group.by = "main_cell_type")
Idents(total_ESCC_all)<-total_ESCC_all$integrated_snn_res.0.3
DimPlot(total_ESCC_all,reduction = "tsne")

#####cellmarker验证

DefaultAssay(total_ESCC_all)<-"RNA"

p1<-DimPlot(total_ESCC_all, reduction = "umap" ,label=T,,raster=FALSE)
p2<-DimPlot(total_ESCC_all, reduction = "umap" ,group.by = "pancreas_gs_prediction",label=T,,raster=FALSE)

#######文章中的marker注释

Idents(total_ESCC_all)<-total_ESCC_all$integrated_snn_res.0.1
DimPlot(total_ESCC_all, reduction = "tsne" ,label=T,raster=FALSE)


DefaultAssay(total_ESCC_all)<-"RNA"

ESCC.markers <- FindAllMarkers(object =total_ESCC_all, only.pos = TRUE, 
                              min.pct = 0, 
                              thresh.use = 0.25)
ESCC.markers$filter<-substring(ESCC.markers$gene,1,3)
ESCC.markers_f<-subset(ESCC.markers,subset = filter!="LOC")

ESCCmarkers_df = ESCC.markers_f %>% group_by(cluster) %>% top_n(n = 40, wt = avg_log2FC)

ESCCkers_df_F<-unique(ESCCmarkers_df$gene)

DefaultAssay(total_ESCC_all)<-"RNA"
Idents(total_ESCC_all)<-total_ESCC_all$integrated_snn_res.0.1
DoHeatmap(total_ESCC_all,features = ESCCmarkers_df$gene,label = F,slot = "scale.data")







celltype_marker<-c("ICAM1","CDH5","CD3E","KRT5","EPCAM","CDH1","MYH11","ACTA2","KIT","CD14","PDPN","KRT7","THY1","CD79A","CD79B","CLDN5","COL3A1","COL1A2",
                   "LY6G","NCF1","CSF1R","CD3D","LILRA4","LYVE1","CD163")





p3<-DotPlot(total_ESCC_all, features = celltype_marker)+RotatedAxis()+
  scale_x_discrete("")+scale_y_discrete("")+scale_color_gradientn(colours = c("white",'dodgerblue','red'))
p3

VlnPlot(total_ESCC_all,features = celltype_marker,pt.size = 0,ncol = 4)


######修改图的样式
df<- p3$data
head(df)

ggplot(df, aes(x = id,y = features.plot)) +
  geom_point(aes(color = avg.exp.scaled, size = pct.exp)) +
  scale_color_gradientn(colors = c("white",'skyblue','yellow','red'), limits = c(-1.3, 2.5)) +
  labs(x = "", y = "")+
  theme_classic() 




ggplot(df, aes((x = factor(id,levels =c("0", "2", "3","4", "6", "8","9","1","7","5","10"))), y = features.plot)) +
  geom_point(aes(color = avg.exp.scaled, size = pct.exp)) +
  scale_color_gradientn(colors = c("white",'skyblue',"yellow",'red'), limits = c(-1.3, 2.5)) +
  labs(x = "", y = "")+
  theme_classic() 




celltype_marker<-unique(celltype_marker)
p3<-DotPlot(total_ESCC_all, features = celltype_marker)+RotatedAxis()+
  scale_x_discrete("")+scale_y_discrete("")
p3
p1 + p2 +p3+ plot_layout(widths = c(1,1,1))
#####堆叠小提琴图
p5<-VlnPlot(total_ESCC_all, features = celltype_marker, pt.size = 0, ncol =4)
#####两张图放在一起观察
p3 +p5+ plot_layout(widths = c(1,1))
######最终注释:添加注释信息
Idents(total_ESCC_all)<-total_ESCC_all$integrated_snn_res.0.1

annotation_curated_main <- read_excel("D:/ESCC/GSE188900/tumor/curated_annotation_mainV2.xlsx")


new_ids_main <- annotation_curated_main$main_cell_type
names(new_ids_main) <- levels(total_ESCC_all)
total_ESCC_all <- RenameIdents(total_ESCC_all, new_ids_main)
total_ESCC_all@meta.data$main_cell_type <- Idents(total_ESCC_all)
Idents(total_ESCC_all)<-total_ESCC_all$main_cell_type
DimPlot(total_ESCC_all, group.by = "main_cell_type",reduction = "tsne", label = T, label.size = 5)


saveRDS(total_ESCC_all,"D:\\ESCC\\GSE188900\\tumor\\escc_tumor_未做scissor.rds")
#########新的尝试
#celltype_marker=c(
#"EPCAM",#上皮细胞 epithelial
#"PECAM1",#内皮细胞 endothelial
#"COL3A1",#成纤维细胞 ESCCroblasts
#"CD163","AIF1",#髓系细胞 myeloid
#"CD79A",#B细胞
#"JCHAIN",#浆细胞 plasma cell
#"CD3D","CD8A","CD4",#T细胞
#"GNLY","NKG7",#NK细胞
#"PTPRC"#免疫细胞
#)

