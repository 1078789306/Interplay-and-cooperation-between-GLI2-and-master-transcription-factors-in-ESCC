library(Seurat)
library(dplyr)
library(reticulate)
library(sctransform)
library(cowplot)
library(ggplot2)
library(viridis)
library(tidyr)
library(magrittr)
library(reshape2)
library(readxl)
library(progeny)
library(readr)
library(stringr)
library(patchwork)
library(clustree)
library(clustree)
library(patchwork)
library(harmony)
gc()
escc_P6<-readRDS("D:\\ESCC\\GSE188900\\P6患者单独合并\\0data\\ESCC_P6_integrate合并_注释后.rds")
table(escc_P6$main_cell_type)
sq_epi<-subset(escc_P6,subset =main_cell_type=="Squamous epithelium")
sq_epi@meta.data$sample[sq_epi$orig.ident=="GSM5691647"|sq_epi$orig.ident=="GSM5691648"]<-"Tumor"
sq_epi@meta.data$sample[sq_epi$orig.ident=="GSM5691649"]<-"Normal"

remove(escc_P6)
gc()
TF_26<-read.table("D:\\ESCC_LIU\\Gene list 2.txt")
markers<-TF_26$V1
Idents(sq_epi)<-sq_epi$sample

table(sq_epi$sample)
DefaultAssay(sq_epi)<-"RNA"
DoHeatmap(sq_epi,TF_26$V1,size=3,slot = 'data')

###tumor
sq_epi_t<-subset(sq_epi,subset = sample=="Tumor")
sq_epi_data<-as.data.frame(sq_epi_t@assays$RNA@data)
sq_epi_data$gene<-rownames(sq_epi_data)
colnames(TF_26)<-"gene"
sq_epi_data<-merge(sq_epi_data,TF_26,by="gene")
rownames(sq_epi_data)<-sq_epi_data[,1]
sq_epi_data<-sq_epi_data[,-1]
corr<-round(cor(t(sq_epi_data)),3)
library(ggcorrplot)
library(corrplot)
ggcorrplot(corr,method ="circle")

col2 <- colorRampPalette( c("#053061","#2166AC","#4393C3", "#92C5DE", "#D1E5F0", "#FFFFFF","#FDDBC7", "#F4A582", "#D6604D", "#B2182B","#67001F"))(100)




# 绘制相关性热图
corrplot(corr, method = "square", col = col2)
