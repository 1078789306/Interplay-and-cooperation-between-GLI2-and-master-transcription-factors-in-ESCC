gc()
reticulate::py_install(packages ='umap-learn')
seu_obj_f<-readRDS("D:\\ESCC\\GSE188900\\P6患者单独合并\\0data\\ESCC_P6_filter.rds")
seu_obj_f <- PercentageFeatureSet(seu_obj_f, pattern = "^MT-", col.name = "pMT")##线粒体计数
seu_obj_f <- PercentageFeatureSet(seu_obj_f, pattern = "^HBA|^HBB", col.name = "pHB")##血红蛋白计数
seu_obj_f <- PercentageFeatureSet(seu_obj_f, pattern = "^RPS|^RPL", col.name = "pRP")##核糖体计数
seu_obj_f <- SCTransform(seu_obj_f, verbose = T, vars.to.regress = c("nCount_RNA", "pMT"), conserve.memory = T)
seu_obj_f <- RunPCA(seu_obj_f,features = NULL,verbose = TRUE)

ElbowPlot(seu_obj_f, ndims = 50)
seu_obj_f <- RunUMAP(seu_obj_f, dims = 1:30)
seu_obj_f <- FindNeighbors(seu_obj_f, dims = 1:30)
DimPlot(seu_obj_f, reduction = "umap",label = T)
seu_obj_f$orig.ident
DimPlot(seu_obj_f, reduction = "umap",split.by = "orig.ident",label = T)
for (i in c(0.1,0.2, 0.3, 0.4, 0.5, 1, 2)) {
  +   seu_obj_f <- FindClusters(seu_obj_f, resolution = i)
  +   print(DimPlot(seu_obj_f, reduction = "umap") + labs(title = paste0("resolution: ", i)))}
table(seu_obj_f$orig.ident)
Idents(seu_obj_f) <- seu_obj_f$orig.ident

saveRDS(seu_obj_f,"D:\\ESCC\\GSE188900\\P6患者单独合并\\0data\\ESCC_merge_UMAP.rds")
