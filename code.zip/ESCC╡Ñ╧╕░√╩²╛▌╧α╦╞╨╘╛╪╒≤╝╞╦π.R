total_ESCC<-readRDS("D:\\ESCC\\GSE188900\\tumor\\escc_scissor_tumor0.005.rds")
escc_epi<-subset(total_ESCC,subset =main_cell_type=="Squamous epithelium")
remove(total_ESCC)
sq_epi_data<-as.data.frame(escc_epi@assays$RNA@data)
sq_epi_data$gene<-rownames(sq_epi_data)
colnames(TF_26)<-"gene"
sq_epi_data<-merge(sq_epi_data,TF_26,by="gene")
rownames(sq_epi_data)<-sq_epi_data[,1]
sq_epi_data<-sq_epi_data[,-1]
corr<-round(cor(t(sq_epi_data)),3)
library(ggcorrplot)
library(corrplot)
ggcorrplot(corr,method ="circle")

col2 <- colorRampPalette( c("#053061","#2166AC","#4393C3", "#92C5DE", "#D1E5F0", "#FFFFFF","#FDDBC7", "#F4A582", "#D6604D", "#B2182B","#67001F"))(100)




# 绘制相关性热图
corrplot(corr, method = "square", col = col2)
gc()
