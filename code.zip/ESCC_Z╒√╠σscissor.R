library(Seurat)

library(Scissor)
library(patchwork)



table(total_ESCC$orig.ident)
total_ESCC<-readRDS("D:\\ESCC\\GSE188900\\tumor\\escc_tumor_未做scissor.rds")

p1<-DimPlot(total_ESCC,group.by ="main_cell_type",reduction = "tsne" )
p1
DefaultAssay(total_ESCC)<-"RNA"
DotPlot(total_ESCC,features = c("TP63","KLF5","SOX2","LDHA","HK2","MIR205HG"))

VlnPlot(total_ESCC,features = c("MIR205HG","PTBP3"),pt.size = 0)

table(total_ESCC$orig.ident)

DefaultAssay(total_ESCC)<-"RNA"
total_ESCC<- NormalizeData(total_ESCC, normalization.method = "LogNormalize", scale.factor = 10000)
table(total_ESCC$orig.ident)
total_ESCC@graphs$integrated_nn=total_ESCC@graphs$integrated_snn
tumor<- Seurat_preprocessing(total_ESCC@assays$RNA@counts, verbose = F)
table(tumor$orig.ident)
remove(total_ESCC)
DefaultAssay(tumor)
ESCC_fpkm_fin<-read.csv("D:/ESCC/GSE188900/0data/ESCC_TCGA_bulk_tumor_COUNT_final.csv",row.names = 1)

ESCC_pheno_fin<-read.csv("D:/ESCC/GSE188900/0data/ESCC_TCGA_tumor_pheno_COUNT_final.csv",row.names = 1)
all(colnames(ESCC_fpkm_fin) == ESCC_pheno_fin$NAME)
ESCC_fpkm_fin<-as.matrix(ESCC_fpkm_fin)    
ESCC_phenotype <- ESCC_pheno_fin[,c(131,129)]
colnames(ESCC_phenotype) <- c("time", "status")
gc()
remove(total_ESCC)
infos1 <- Scissor(ESCC_fpkm_fin, tumor, ESCC_phenotype, alpha = 0.005,
                  family = "cox", Save_file = 'Scissor_ESCC_survival.RData')
gc()
Scissor_select <- rep(0, ncol(tumor))#创建一个列表，用来表示4102个细胞， 
names(Scissor_select) <- colnames(tumor)#给列表中每一个数赋予细胞编号 
Scissor_select[infos1$Scissor_pos] <- 1#被选为Scissor+的细胞赋值为1 
Scissor_select[infos1$Scissor_neg] <- 2#被选为Scissor-的细胞赋值为2 
total_ESCC<- AddMetaData(total_ESCC, metadata = Scissor_select, col.name = "scissor")#将表示4102个细胞分类的列表添加到tumor这个Seurat对象中 

DimPlot(total_ESCC, reduction = 'tsne', group.by = 'scissor', cols = c('grey','indianred1','royalblue'), pt.size = 1.2, order = c(2,1))

Idents(total_ESCC)<-total_ESCC$main_cell_type


prop.table(table(Idents(total_ESCC)))
table(Idents(total_ESCC), total_ESCC$main_cell_type)#各组不同细胞群细胞数

Idents(total_ESCC)<-total_ESCC$orig.ident
Cellratio <- prop.table(table(Idents(total_ESCC), total_ESCC$scissor,total_ESCC$main_cell_type), margin = 3)#计算各组样本不同细胞群比例
Cellratio <- as.data.frame(Cellratio)



Cellratio <- prop.table(table(Idents(total_ESCC), total_ESCC$orig.ident), margin = 2)#计算各组样本不同细胞群比例
Cellratio <- as.data.frame(Cellratio)

DefaultAssay(total_ESCC)<-"SCT"

FeaturePlot(total_ESCC,features = "MIR205HG",reduction = "tsne",pt.size = 1,cols = c("grey", "#CD5B45"))

Idents(total_ESCC)<-total_ESCC$scissor
library(ggpubr)
my_comparisons<-list(c("0","1"))
VlnPlot(total_ESCC,features = "MIR205HG",pt.size = 0)+
  NoLegend() +
  theme(axis.text.x = element_text(angle = 90, hjust = 1)) +
  stat_compare_means(comparisons = my_comparisons)+ylim(0,6.5)
  



saveRDS(total_ESCC,"D:\\ESCC\\GSE188900\\tumor\\escc_scissor_tumor0.005.rds")


table(total_ESCC$orig.ident)




