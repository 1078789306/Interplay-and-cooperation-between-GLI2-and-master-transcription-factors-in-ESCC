#####数据中只有P6有一组正常，所以把p6患者提取出来
table(ESCC$orig.ident)
ESCC_P6<-subset(ESCC,c(orig.ident=="GSM5691647"|orig.ident=="GSM5691648"|orig.ident=="GSM5691649"))
DimPlot(ESCC_P6, reduction = "umap" ,label=T,raster=FALSE)
DimPlot(total_MHeR, reduction = "umap" ,label=T,raster=FALSE,split.by = "orig.ident")
###对ESCCp6单独合并
setwd("D:/ESCC/GSE188900/0data/")
getwd()
library(Seurat)
library(dplyr)
library(reticulate)
library(sctransform)
library(cowplot)
library(ggplot2)
library(viridis)
library(tidyr)
library(magrittr)
library(reshape2)
library(readxl)
library(progeny)
library(readr)
library(stringr)
library(clustree)
library(patchwork)
######筛选条件的选择
nFeature_lower <- 500
nFeature_upper <- 10000
nCount_lower <- 1000
nCount_upper <- 100000
pMT_lower <- 0
pMT_upper <- 10
pHB_lower <- 0
pHB_upper <- 5
####数据的读入：食管鳞癌p6数据单独读入
samples <- read_excel("D:/ESCC/GSE188900/sample.xlsx", range = cell_cols("A:A")) %>% .$sample_id
samples<-samples[c(6:8)]

######数据读入
for (i in seq_along(samples)){
  assign(paste0("scs_data", i), Read10X(data.dir = paste0("D:/ESCC/GSE188900/", samples[i])))
}


# Initialize the Seurat object with the raw (non-normalized data).

for (i in seq_along(samples)){
  assign(paste0("seu_obj", i), CreateSeuratObject(counts = eval(parse(text = paste0("scs_data", i))), project = samples[i], min.cells = 5))
}

seu_obj <- merge(seu_obj1, y = c(seu_obj2, seu_obj3), add.cell.ids = samples, project = "ESCC")
#######保存数据
dim(seu_obj)
saveRDS(seu_obj,"D:\\ESCC\\GSE188900\\P6患者单独合并\\0data\\ESCC_p6.rds")
