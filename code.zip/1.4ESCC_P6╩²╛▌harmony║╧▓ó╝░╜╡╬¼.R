seu_obj_f<-readRDS("D:\\ESCC\\GSE188900\\P6患者单独合并\\0data\\ESCC_merge_UMAP.rds")

####开始harmony合并
seu_obj_f <-seu_obj_f%>% RunHarmony("orig.ident", plot_convergence = T)
#最终使用的维数
pct<-seu_obj_f [["harmony"]]@stdev/sum(seu_obj_f [["harmony"]]@stdev)*100
cumu<-cumsum(pct)
co1<-which(cumu >80 & pct<5)[1]
co2 <- sort(which((pct[1:length(pct) - 1] - pct[2:length(pct)]) > 0.1), decreasing = T)[1] + 1
co2 <- min(co1,co2)
co2#这里是数据选择的最优主成分
pc.num=1:co2
#降维聚类
seu_obj_f <- RunUMAP(seu_obj_f,reduction="harmony", dims=pc.num,seed.use=123456L)
seu_obj_f <- RunTSNE(seu_obj_f,reduction="harmony", dims=pc.num,seed.use = 123456)
seu_obj_f<- FindNeighbors(seu_obj_f,reduction="harmony",dims = pc.num,k.param = 20)
DimPlot(seu_obj_f,reduction = "umap")

seu_obj_f <- FindClusters(seu_obj_f,random.seed=123456,resolution=c(0.1,0.2,0.3,0.4,0.5,0.8,1,1.2))

Idents(seu_obj_f)<-seu_obj_f$RNA_snn_res.0.1

DimPlot(seu_obj_f,reduction = "umap")
saveRDS(seu_obj_f,"D:\\BaiduNetdiskDownload\\RUXIAN\\result2024.1.19\\B细胞\\B细胞harmony合并.rds")
