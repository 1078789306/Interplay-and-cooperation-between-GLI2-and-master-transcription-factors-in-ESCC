############integrate合并
seu_obj<-readRDS("D:\\ESCC\\GSE188900\\0data\\ESCC_UMAP.rds")
table(seu_obj$orig.ident)
seu_obj_f<-subset(seu_obj,subset=c(orig.ident=="GSM5691642"|orig.ident=="GSM5691643"|orig.ident=="GSM5691644"|orig.ident=="GSM5691645"|orig.ident=="GSM5691646"|orig.ident=="GSM5691647"|orig.ident=="GSM5691648"))

remove(seu_obj)

split_seurat <- SplitObject(seu_obj_f, split.by = "orig.ident")
remove(seu_obj)
# bm280k.list2=lapply(X = split_seurat, FUN = function(x) {
#   x <- PercentageFeatureSet(x, pattern = "^mt-",      col.name = "percent.mt")# 统计线粒体
#   x <- PercentageFeatureSet(x, pattern = "^Hba|^Hbb", col.name = "percent.HB")
#   x <- PercentageFeatureSet(x, pattern = "^Rps|^Rpl", col.name = "percent.RP")#核糖体
#   x <- subset(x, subset = nFeature_RNA > nFeature_lower & nFeature_RNA < nFeature_upper & 
#                 nCount_RNA > nCount_lower & nCount_RNA < nCount_upper & percent.mt < pMT_upper & percent.HB < pHB_upper)
#   x <- SCTransform(x,verbose = T)##标准化
# })

###去线粒体
options(future.globals.maxSize= 100000000000000)
total.features <- SelectIntegrationFeatures(object.list = split_seurat, nfeatures = 3000)
total.list <- PrepSCTIntegration(object.list = split_seurat, anchor.features = total.features,   verbose = FALSE)
#,reference =2 ，以第2个为参考，加快速度不影响结果（选取包含细胞最多的组作为reference）
gc()
total.anchors <- FindIntegrationAnchors(object.list = total.list, normalization.method = "SCT", anchor.features = total.features, verbose = FALSE,reference =2)


total <- IntegrateData(anchorset = total.anchors, normalization.method = "SCT", verbose = FALSE)
dim(total)

table(total$orig.ident)
remove(split_seurat)
total_MHeR=total
remove(total)
total_MHeR <- RunPCA(total_MHeR)
ElbowPlot(total_ESCC, ndims = 50)
total_MHeR <- RunUMAP(total_MHeR, dims = 1:50, verbose = T)
total_MHeR <- FindNeighbors(total_MHeR, dims = 1:50)
p1<-DimPlot(total_MHeR, reduction = "umap",split.by = "orig.ident" ,label=T,raster=FALSE)
Idents(total_MHeR)<-total_MHeR$orig.ident
DimPlot(total_MHeR, reduction = "umap" ,label=T,raster=FALSE)
DimPlot(total_MHeR, reduction = "umap" ,label=T,raster=FALSE,split.by = "orig.ident")
total_MHeR$orig.ident
total_MHeR <- RunTSNE(total_MHeR, dims = 1:50, verbose = T)
p2<-DimPlot(total_MHeR, reduction = "tsne",split.by = "orig.ident" ,label=T,,raster=FALSE)

DimPlot(total_MHeR, reduction = "tsne" ,label=T,,raster=FALSE)
DimPlot(total_MHeR, reduction = "tsne" ,label=T,split.by = "orig.ident",raster=FALSE)
p1 + p2 + plot_layout(widths = c(2, 2))


for (i in c(0.1,0.2, 0.3, 0.4, 0.5,0.6,0.7,0.8,0.9, 1, 2)) {
  total_MHeR <- FindClusters(total_MHeR,resolution = i)
  print(DimPlot(total_MHeR, reduction = "umap") + labs(title = paste0("resolution: ", i)))
}

Idents(total_MHeR)<-total_MHeR$orig.ident
DimPlot(total_MHeR,reduction = "tsne")

DimPlot(total_MHeR,reduction = "tsne",split.by = "orig.ident",ncol = 2)


saveRDS(total_MHeR,'ESCCintegrate合并_降维数据.rds')
