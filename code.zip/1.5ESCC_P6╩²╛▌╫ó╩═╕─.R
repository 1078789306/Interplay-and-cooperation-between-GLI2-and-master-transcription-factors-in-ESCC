gc()
#####cellmarker验证
total_ESCC<-readRDS("D:\\ESCC\\GSE188900\\P6患者单独合并\\0data\\ESCC_P6_integrate合并_降维数据.rds")

DefaultAssay(total_ESCC)<-"RNA"
Idents(total_ESCC)<-total_ESCC$integrated_snn_res.0.1

p1<-DimPlot(total_ESCC, reduction = "tsne" ,label=T,,raster=FALSE)
p1
p2<-DimPlot(total_ESCC, reduction = "umap" ,group.by = "pancreas_gs_prediction",label=T,,raster=FALSE)

#######文章中的marker注释




celltype_marker<-c("KRT5","KRT8","CDH1","KRT18","KRT7","EPCAM","CD3E","CD3D",
                   "CD79A","CD79B","COL1A1","COL1A2","ACTA2","MYH11",
                   "CD68","CD163","CDH5","ICAM1","KIT")



celltype_marker<-unique(celltype_marker)

p3<-DotPlot(total_ESCC, features = celltype_marker)+RotatedAxis()+
  scale_x_discrete("")+scale_y_discrete("")+scale_color_gradientn(colours = c("white",'dodgerblue','red'))+coord_flip()
p3

######修改图的样式
df<- p3$data
head(df)






ggplot(df, aes((x = factor(id,levels =c("0","2", "3", "10","1","9", "4", "5","6","7","8","11"))), y = features.plot)) +
  geom_point(aes(color = avg.exp.scaled, size = pct.exp)) +
  scale_color_gradientn(colors = c("white",'skyblue',"yellow","orange",'red'), limits = c(-1.3, 2.5)) +
  labs(x = "", y = "")+
  theme_classic() 




celltype_marker<-unique(celltype_marker)
p3<-DotPlot(total_ESCC, features = celltype_marker)+RotatedAxis()+
  scale_x_discrete("")+scale_y_discrete("")
p3
p1 + p2 +p3+ plot_layout(widths = c(1,1,1))
#####堆叠小提琴图
p5<-VlnPlot(total_ESCC, features = celltype_marker, pt.size = 0, ncol =4)
p5
#####两张图放在一起观察
p3 +p5+ plot_layout(widths = c(1,1))
######最终注释:添加注释信息
Idents(total_ESCC)<-total_ESCC$integrated_snn_res.0.1

annotation_curated_main <- read_excel("D:\\ESCC\\GSE188900\\P6患者单独合并\\P6患者重新分析2023.10.8\\0data\\curated_annotation_mainV2.xlsx")


new_ids_main <- annotation_curated_main$main_cell_type
names(new_ids_main) <- levels(total_ESCC)
total_ESCC <- RenameIdents(total_ESCC, new_ids_main)
total_ESCC@meta.data$main_cell_type <- Idents(total_ESCC)
Idents(total_ESCC)<-total_ESCC$main_cell_type
DimPlot(total_ESCC, group.by = "main_cell_type",reduction = "tsne", label = T, label.size = 5)


saveRDS(total_ESCC,"D:\\ESCC\\GSE188900\\P6患者单独合并\\0data\\ESCC_P6_integrate合并_注释后.rds")
#########新的尝试
#celltype_marker=c(
  #"EPCAM",#上皮细胞 epithelial
  #"PECAM1",#内皮细胞 endothelial
  #"COL3A1",#成纤维细胞 fibroblasts
  #"CD163","AIF1",#髓系细胞 myeloid
  #"CD79A",#B细胞
  #"JCHAIN",#浆细胞 plasma cell
  #"CD3D","CD8A","CD4",#T细胞
  #"GNLY","NKG7",#NK细胞
  #"PTPRC"#免疫细胞
#)

