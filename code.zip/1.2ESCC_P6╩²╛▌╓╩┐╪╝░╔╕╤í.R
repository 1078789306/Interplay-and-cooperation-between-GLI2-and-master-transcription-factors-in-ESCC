gc()

seu_obj<-readRDS("D:\\ESCC\\GSE188900\\P6患者单独合并\\0data\\ESCC_p6.rds")
# The [[ operator can add columns to object metadata. This is a great place to stash QC stats
seu_obj[["percent.mt"]] <- PercentageFeatureSet(seu_obj, pattern = "^MT-")

# 查看QC指标
# Show QC metrics for the first 5 cells
head(seu_obj@meta.data, 5)
######可视化QC的指标

VlnPlot(seu_obj, features = c("nFeature_RNA", "nCount_RNA", "percent.mt"), group.by = "orig.ident", ncol = 3, log = T,raster=FALSE)

######每个指标之间的相关性（相关性图的作用：让我们更好的认识到筛选条件，首先具有生物学意义的细胞，那其nFeature_RNA与nCount_RNA应该呈现近似的正相关，且越靠近左下，我们会认为细胞的质量越差（一般认为有生物学意义的细胞其基因数量与mRNA数量应该都高），但是其基因数量与mRNA数量又不能都太高，这样可能是因为一个液滴中包含了多个细胞的缘故。而mt与nCount_RNA之间的关系图则主要是表示若mRNA数量极少而线粒体几多可能是受损或者垂死的细胞其细胞质mRNA通过破损的核膜泄露）
######ncount_RNA代表了转录成mRNA的多少，那它是不是筛选的金标准呢？如果一个样本其ncount_RNA很低代表了什么呢
plot1 <- FeatureScatter(seu_obj, feature1 = "nCount_RNA", feature2 = "percent.mt",raster=FALSE)
plot2 <- FeatureScatter(seu_obj, feature1 = "nCount_RNA", feature2 = "nFeature_RNA",raster=FALSE)
plot1 + plot2
#####过滤

seu_obj_f <- subset(seu_obj, subset = nFeature_RNA > nFeature_lower & nFeature_RNA < nFeature_upper & nCount_RNA > nCount_lower & nCount_RNA < nCount_upper & percent.mt < pMT_upper )

#######看一下筛选前后细胞数目差异，若差异太大，需要更改筛选条件或者换数据
table(seu_obj$orig.ident)
table(seu_obj_f$orig.ident)


saveRDS(seu_obj_f,"D:\\ESCC\\GSE188900\\P6患者单独合并\\0data\\ESCC_P6_filter.rds")
