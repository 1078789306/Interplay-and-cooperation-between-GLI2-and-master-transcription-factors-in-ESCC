library(harmony)
library(DoubletFinder)
library(tidyverse)
library(Seurat)
library(patchwork)
sq_epi<-readRDS("D:\\ESCC\\196756+188900\\0DATA\\epi.rds")


seurat_obj_epi<-sq_epi@assays$RNA@counts


seurat_obj_epi<-as.matrix(seurat_obj_epi)
seurat_obj_epi <- CreateSeuratObject(counts = seurat_obj_epi,
                                          min.features = 200,
                                          min.cells = 5, 
                                          project = "epi")





head(seurat_obj_epi@meta.data,5)
seurat_obj_epi[["percent.mt"]] <- PercentageFeatureSet(seurat_obj_epi, pattern = "^MT-")
seurat_obj_epi <- SCTransform(seurat_obj_epi, verbose = T, vars.to.regress = c("nCount_RNA", "percent.mt"), conserve.memory = T)


seurat_obj_epi  <- RunPCA(seurat_obj_epi , verbose = F)

ElbowPlot(seurat_obj_epi , ndims = 50)


gc()
library(harmony)

seurat_obj_epi  <-seurat_obj_epi %>% RunHarmony("orig.ident", plot_convergence = T)

pct<-seurat_obj_epi  [["harmony"]]@stdev/sum(seurat_obj_epi  [["harmony"]]@stdev)*100
cumu<-cumsum(pct)
co1<-which(cumu >80 & pct<5)[1]
co2 <- sort(which((pct[1:length(pct) - 1] - pct[2:length(pct)]) > 0.1), decreasing = T)[1] + 1
co2 <- min(co1,co2)

pc.num=1:co2

seurat_obj_epi  <- RunUMAP(seurat_obj_epi ,reduction="harmony", dims=pc.num,seed.use=123456L)
seurat_obj_epi  <- RunTSNE(seurat_obj_epi ,reduction="harmony", dims=pc.num,seed.use = 123456)
seurat_obj_epi <- FindNeighbors(seurat_obj_epi ,reduction="harmony",dims = pc.num,k.param = 20)
DimPlot(seurat_obj_epi ,reduction = "tsne")

seurat_obj_epi  <- FindClusters(seurat_obj_epi ,random.seed=123456,resolution=c(0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,1,1.2))
cpoykat<-read.table("D:\\ESCC\\196756+188900\\OS_copykat_prediction.txt",header = T)
colnames(cpoykat)[1]<-c("cell")
metdata<-seurat_obj_epi@meta.data
metadata_merge<-metdata
metadata_merge$cell<-rownames(metadata_merge)

metadata_merge<-merge(metadata_merge,cpoykat,by="cell")

rownames(metadata_merge)<-metadata_merge[,1]
metadata_merge<-metadata_merge[,-1]


sq_epi<-AddMetaData(sq_epi,metadata_merge)


Idents(sq_epi)<-sq_epi$copykat.pred
DimPlot(sq_epi)
table(sq_epi$sample)
sq_epi<-subset(sq_epi,subset=sample=="Tumor")
table(sq_epi$copykat.pred)

copykat_pred_counts <- c(aneuploid = 6763, diploid = 6059, `not.defined` = 1276)

# 绘制柱状图
barplot(copykat_pred_counts,
        main = "CopyKAT Prediction Counts", 
        xlab = "Prediction Type",            
        ylab = "Frequency",                  
        col = c("skyblue", "lightgreen", "khaki"),
        las = 1,                             
        ylim = c(0, max(copykat_pred_counts) + 500)) 


text(x = barplot(copykat_pred_counts, plot = FALSE),
     y = copykat_pred_counts,
     label = copykat_pred_counts,
     pos = 3,                                
     offset = 0.5,                           
     cex = 0.8)                              

DimPlot(sq_epi)
moncle<-subset(sq_epi,subset=c(copykat.pred=="diploid"|copykat.pred=="aneuploid"))
DotPlot(moncle,features = c("RUNX1","TP63","GLI2"))



expr <- moncle@assays$RNA
gene_expression <- expr %>% .['RUNX1',] %>% as.data.frame() %>% t()
gene_expression <- as.data.frame(gene_expression)
metadata_moncle<-moncle@meta.data
metadata_moncle$cell<-rownames(metadata_moncle)
metadata_moncle<-metadata_moncle[,c(23,24)]
colnames(gene_expression) <- 'RUNX1'

gene_expression$cell <- rownames(gene_expression)
gene_expression<-merge(gene_expression,metadata_moncle,by="cell")
table(gene_expression$copykat.pred)

gene_expression_an<-subset(gene_expression,subset=copykat.pred=="aneuploid")
gene_expression_di<-subset(gene_expression,subset=copykat.pred=="diploid")

gene_expression_sel <- gene_expression_an[which(gene_expression_an$RUNX1 > 0),]
gene_expression_sel <- gene_expression_di[which(gene_expression_di$RUNX1 > 0),]

dim(gene_expression_sel) / dim(gene_expression)




VlnPlot(moncle,features =c("RUNX1","TP63"),pt.size =0  )+stat_compare_means(comparisons = comparisons)



a<-VlnPlot(moncle,features = c("RUNX1"),pt.size = 0)+
  NoLegend() +
  theme(axis.text.x = element_text(angle = 90, hjust = 1)) +
  stat_compare_means(comparisons = comparisons, label = "p.format",method =  "wilcox.test") +
  ylim(0,2.5)
a

gc()
epi_counts<-as.data.frame(t(as.matrix(moncle@assays$SCT@data)))
epi_meatdata<-moncle@meta.data

GLI2<-as.data.frame(epi_counts$GLI2)
GLI2$cell<-rownames(epi_counts)
colnames(GLI2)[1]<-"GLI2_expression"
epi_meatdata$cell<-rownames(epi_meatdata)
metadata<-merge(GLI2,epi_meatdata,by="cell")
comparisons<-list(c("aneuploid","diploid"))


library(ggpubr)

p<-ggplot(metadata, aes(x = reorder(copykat.pred,GLI2_expression),GLI2_expression)) # x分组变量，y表达变量

b<-p+geom_violin(aes(fill = copykat.pred))+#geom_boxplot(width = 0.2)+
  guides(fill = "none") + xlab(NULL) + theme_classic()+ggtitle("epi_GLI2") +NoLegend() +
  theme(axis.text.x = element_text(angle = 90, hjust = 1)) +
  stat_compare_means(comparisons = comparisons, label = "p.format",method =  "wilcox.test") +
  ylim(0,1.2)


b








library(monocle)
library(dplyr)
library(Seurat)
library(patchwork)
library(tidyr)



celltype<-moncle$copykat.pred
celltype<-as.data.frame(celltype)
celltype$cellname<-rownames(celltype)

celltype$sample<-substr(celltype$cellname,1,10)
celltype2<-unite(celltype,"cellnamenew",c("celltype","sample"), sep="-", remove = F)
moncel2<-moncle
moncel2$cellname<-celltype2$cellnamenew


expr_matrix <- as(as.matrix(moncel2@assays$RNA@counts), 'sparseMatrix')


p_data <- moncel2@meta.data
#p_data$celltype <- pbmc@active.ident  ##整合每个细胞的细胞鉴定信息到p_data里面。如果已经添加则不必重复添加
f_data <- data.frame(gene_short_name = row.names(moncel2),row.names = row.names(moncel2))

gc()

pd <- new('AnnotatedDataFrame', data = p_data) 
fd <- new('AnnotatedDataFrame', data = f_data)
rownames(fd)
rownames(expr_matrix)
expr_matrix<- expr_matrix[rownames(fd), ]



identical(rownames(fd),rownames(expr_matrix))

remove(moncle)


cds <- newCellDataSet(expr_matrix,
                      phenoData = pd,
                      featureData = fd,
                      lowerDetectionLimit = 0.5,
                      expressionFamily = negbinomial.size())

remove(expr_matrix)
library(data.table)
gc()
cds <- estimateSizeFactors(cds)
cds <- estimateDispersions(cds)
cds <- detectGenes(cds, min_expr = 0.1)
gc()
dim(cds)

expressed_genes <- row.names(subset(fData(cds),
                                    num_cells_expressed >= 10)) #过滤掉在小于10个细胞中表达的基因，还剩11095个基因。


Idents(moncel2)<-moncel2$copykat.pred
table(moncel2$copykat.pred)
DefaultAssay(moncel2)
deg.cluster <- FindAllMarkers(moncel2,min.pct = 0.1,logfc.threshold = 0.25)
express_genes <- subset(deg.cluster,p_val<0.05)$gene
cds <- setOrderingFilter(cds, express_genes)
plot_ordering_genes(cds)


diff <- differentialGeneTest(cds[express_genes,],fullModelFormulaStr="~copykat.pred",cores=1) 

head(diff)


deg <- subset(diff, qval < 0.01) 
deg <- deg[order(deg$qval,decreasing=F),]
head(deg)


write.table(deg,file="train.monocle.DEG.xlsx",col.names=T,row.names=F,sep="\t",quote=F)
DimPlot(moncel, reduction = "umap",group.by = "integrated_snn_res.0.1")

ordergene <- rownames(deg) 
cds <- setOrderingFilter(cds, ordergene)  

cds <- reduceDimension(cds, max_components = 2,
                       method = 'DDRTree')

gc()
cds <- orderCells(cds)

cds <- orderCells(cds, root_state = 3)

plot_cell_trajectory(cds,color_by="Pseudotime", size=1,show_backbone=TRUE) 

plot_cell_trajectory(cds,color_by="main_cell_type", size=1,show_backbone=TRUE)

plot_cell_trajectory(cds, color_by = "copykat.pred",size=1,show_backbone=TRUE)
cds$orig.ident
cds$SCT_snn_res.0.1
plot_cell_trajectory(cds, color_by = "SCT_snn_res.0.1",size=1,show_backbone=TRUE)
plot_cell_trajectory(cds, color_by = "State",size=1,show_backbone=TRUE)


exprData <- cds@assayData$exprs
exprData <- LogNormalize(exprData) 
cds$TP63<- exprData["TP63",] 
plot_cell_trajectory(cds, color_by = "TP63",cell_size=1,show_backbone=TRUE)+scale_colour_gradient(low="grey",high = "red")












