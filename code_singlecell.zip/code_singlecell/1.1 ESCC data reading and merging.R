setwd("D:\\ESCC\\196756+188900\\")
getwd()
library(Seurat)
library(dplyr)
library(reticulate)
library(sctransform)
library(cowplot)
library(ggplot2)
library(viridis)
library(tidyr)
library(magrittr)
library(reshape2)
library(readxl)
library(progeny)
library(readr)
library(stringr)
library(clustree)
library(patchwork)

nFeature_lower <- 500
nFeature_upper <- 10000
nCount_lower <- 1000
nCount_upper <- 100000
pMT_lower <- 0
pMT_upper <- 20
pHB_lower <- 0
pHB_upper <- 5

samples <- read_excel("sample.xlsx", range = cell_cols("A:A")) %>% .$sample_id



for (i in seq_along(samples)){
  assign(paste0("scs_data", i), Read10X(data.dir = paste0("D:\\ESCC\\196756+188900\\", samples[i])))
}


# Initialize the Seurat object with the raw (non-normalized data).

for (i in seq_along(samples)){
  assign(paste0("seu_obj", i), CreateSeuratObject(counts = eval(parse(text = paste0("scs_data", i))), project = samples[i], min.cells = 5))
}

seu_obj <- merge(seu_obj1, y = c(seu_obj2, seu_obj3,seu_obj4,seu_obj5,seu_obj6,seu_obj7,seu_obj8,seu_obj9,seu_obj10,seu_obj11,seu_obj12,seu_obj13,seu_obj14), add.cell.ids = samples, project = "ESCC")

dim(seu_obj)
saveRDS(seu_obj,"D:\\ESCC\\196756+188900\\0DATA\\ESCC_merge.rds")
