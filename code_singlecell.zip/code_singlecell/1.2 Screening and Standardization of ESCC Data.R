library(Seurat)
library(dplyr)
library(reticulate)
library(sctransform)
library(cowplot)
library(ggplot2)
library(viridis)
library(tidyr)
library(magrittr)
library(reshape2)
library(readxl)
library(progeny)
library(readr)
library(stringr)
library(clustree)
library(patchwork)

nFeature_lower <- 500
nFeature_upper <- 10000
nCount_lower <- 1000
nCount_upper <- 100000
pMT_lower <- 0
pMT_upper <- 20
pHB_lower <- 0
pHB_upper <- 5
gc()
seu_obj<-readRDS("D:\\ESCC\\196756+188900\\0DATA\\ESCC_merge.rds")
# The [[ operator can add columns to object metadata. This is a great place to stash QC stats
seu_obj[["percent.mt"]] <- PercentageFeatureSet(seu_obj, pattern = "^MT-")


# Show QC metrics for the first 5 cells
head(seu_obj@meta.data, 5)

qcparams <- c("nFeature_RNA", "nCount_RNA", "percent.mt" )
for (i in seq_along(qcparams)){
  print(VlnPlot(object = seu_obj, features = qcparams[i], group.by = "orig.ident", pt.size = 0))
}
for (i in seq_along(qcparams)){
  print(RidgePlot(object = seu_obj, features = qcparams[i], group.by = "orig.ident"))
}

VlnPlot(seu_obj, features = c("nFeature_RNA", "nCount_RNA", "percent.mt"), group.by = "orig.ident", ncol = 3, log = T,pt.size = 0,raster=FALSE)


plot1 <- FeatureScatter(seu_obj, feature1 = "nCount_RNA", feature2 = "percent.mt",raster=FALSE)
plot2 <- FeatureScatter(seu_obj, feature1 = "nCount_RNA", feature2 = "nFeature_RNA",raster=FALSE)
plot1 + plot2
gc()




seu_obj_f <- subset(seu_obj, subset = nFeature_RNA > nFeature_lower & nFeature_RNA < nFeature_upper & nCount_RNA > nCount_lower & nCount_RNA < nCount_upper & percent.mt < pMT_upper )
table(seu_obj_f$orig.ident)
saveRDS(seu_obj_f,"D:\\ESCC\\196756+188900\\0DATA\\ESCC_filter.rds")
seu_obj_f<-readRDS("D:\\ESCC\\196756+188900\\0DATA\\ESCC_filter.rds")
gc()
reticulate::py_install(packages ='umap-learn')

seu_obj_f <- PercentageFeatureSet(seu_obj_f, pattern = "^MT-", col.name = "pMT")
seu_obj_f <- PercentageFeatureSet(seu_obj_f, pattern = "^HBA|^HBB", col.name = "pHB")
seu_obj_f <- PercentageFeatureSet(seu_obj_f, pattern = "^RPS|^RPL", col.name = "pRP")
remove(seu_obj)
gc()
seu_obj_f <- SCTransform(seu_obj_f, verbose = T, vars.to.regress = c("nCount_RNA", "pMT"), conserve.memory = T)
